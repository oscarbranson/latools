"""
Helper functions used by LAtools.

(c) Oscar Branson : https://github.com/oscarbranson
"""