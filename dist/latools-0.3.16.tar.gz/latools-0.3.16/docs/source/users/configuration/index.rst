###################
Configuration Guide
###################

.. only:: html

    :Release: |version|
    :Date: |today|

.. toctree::
    :maxdepth: 2

    howto.rst
    data-formats.rst
    srm-file.rst
    configurations.rst