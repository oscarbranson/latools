"""
Functions to aid in pre-processing data that is not in the correct
format for LAtools.

(c) Oscar Branson : https://github.com/oscarbranson
"""
from .split import long_file